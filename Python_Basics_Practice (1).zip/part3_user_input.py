# Part 3: User Input
name = input("Enter your name: ")
hobby = input("Enter your hobby: ")
print(f"My name is {name} and my hobby is {hobby}.")