# Part 2: String Exercises
mystring = "a1cbhdzafghx3792by80tsuyhxer"

# a) Length of the string
print("Length of mystring:", len(mystring))

# b) Substring from 10th to 15th character (inclusive)
print("Substring (10th-15th):", mystring[9:15])

# c) Check if "hx5" exists without using if
exists = "hx5" in mystring
print('"hx5" exists in mystring:', exists)