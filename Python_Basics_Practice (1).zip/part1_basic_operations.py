# Part 1: Basic Python Operations
print("Hello World!!!")

# Arithmetic operations
print(5 + 3)
print(2 ** 8)
print(7 / 2)
print(7 % 2)

# Variables and string formatting
name = "Alaa"
print(f"Hello, {name}")

x = None
print(type(x))

# String manipulation
print("one\nTwo\nThree")
y = "quick brown fox"
print(y[:])
print(y[1:6])
print(y[:6])
print(y[:-1])
print(y[:-2])
print(y.title())

z = "    Excellent  "
print(len(z))
w = z.strip()
print(w)
print(len(w))

# Formatted string
price = 30
txt = f"The price is {price:.2f} dollars"
print(txt)
price += 1
print(price)